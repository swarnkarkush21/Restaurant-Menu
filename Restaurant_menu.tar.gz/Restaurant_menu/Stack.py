# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kush/Qt/PyQt/Stack.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from mainwindow import Ui_MainWindow
from homepage import Ui_HomePage

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_StackedWidget(object):
    def setupUi(self, StackedWidget):
        StackedWidget.setObjectName(_fromUtf8("StackedWidget"))
        StackedWidget.resize(640, 480)
        self.page = QtGui.QWidget()
        self.page.setObjectName(_fromUtf8("page"))
        StackedWidget.addWidget(self.page)
        self.page1 = QtGui.QWidget()
        self.page1.setObjectName(_fromUtf8("page1"))
        StackedWidget.addWidget(self.page1)

        self.retranslateUi(StackedWidget)
        QtCore.QMetaObject.connectSlotsByName(StackedWidget)

        def __init__(self):
            super(self).__init__()
            self.buttonNext.clicked.connect(self.handleButtonNext)
            self.buttonPrev.clicked.connect(self.handleButtonPrev)

        def handleButtonNext(self):
            index = self.stackedWidget.currentIndex() + 1
            if index < self.stackedWidget.count():
                self.stackedWidget.setCurrentWidget(index)

        def handleButtonPrev(self):
            index = self.stackedWidget.currentIndex() - 1
            if index >= 0:
                self.stackedWidget.setCurrentWidget(index)

    def retranslateUi(self, StackedWidget):
        StackedWidget.setWindowTitle(_translate("StackedWidget", "StackedWidget", None))

