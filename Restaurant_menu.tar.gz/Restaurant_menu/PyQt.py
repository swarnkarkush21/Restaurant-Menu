import sys, os
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from mainwindow import Ui_MainWindow
from homepage import Ui_HomePage
from signup import Ui_Dialog

def window():
    f = QFrame()
    palette = QPalette()
    layout = QHBoxLayout()
    palette.setBrush(QPalette.Background,
                     QBrush(QPixmap("/home/kush/Downloads/Images/restaurant.jpg")))
    f.setFixedSize(400, 400)
    f.setLayout(layout)
    f.setPalette(palette)
    f.show()

    w = QWidget(f)
    b = QLabel(w)
    b.setText("Welcome To Krishna Restaurant!")
    w.setGeometry(100, 100, 250, 200)
    b.move(10, 1)
    b0 = QPushButton(w)
    b0.setText("Food!")
    b0.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/food/chenise_food/chiwmen.jpg")))
    b0.move(75, 20)
    b0.clicked.connect(b0_clicked)
    b1 = QPushButton(w)
    b1.setText("Cold Drink!")
    b1.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/cold drink/orange_juice.jpg")))
    b1.move(75, 50)
    QObject.connect(b1, SIGNAL("clicked()"), b1_clicked)
    b2 = QPushButton(w)
    b2.setText("Scanks!")
    b2.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/Scanks/Scanks3.jpg")))
    b2.move(75, 80)
    QObject.connect(b2, SIGNAL("clicked()"), b2_clicked)
    b3 = QPushButton(w)
    b3.setText("Fast Food!")
    b3.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/fast food/pasta.jpg")))
    b3.move(75, 110)
    QObject.connect(b3, SIGNAL("clicked()"), b3_clicked)
    b4 = QPushButton(w)
    b4.setText("Tea / Coffee!")
    b4.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/Tea & Coffee /Tea.jpg")))
    b4.move(75, 140)
    QObject.connect(b4, SIGNAL("clicked()"), b4_clicked)
    b5 = QPushButton(w)
    b5.setText("Salad!")
    b5.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/salad/fruit_salad.jpg")))
    b5.move(75, 170)
    QObject.connect(b5, SIGNAL("clicked()"), b5_clicked)
    w.setWindowTitle("PyQt")
    w.show()
    sys.exit(w.exec_())

def b0_clicked():
    print "Your Choice is Food! Please make an order!"
    d = QDialog()
    b = QLabel(d)
    b.setText("Welcome To Krishna Restaurant!")
    b.move(10, 1)
    f0 = QPushButton(d)
    f0.setText("chenise_food!")
    f0.setIcon(QIcon(QPixmap("/home/kush/Downloads/Images/food/chenise_food/chiwmen.jpg")))
    f0.move(75, 20)
    f0.clicked.connect(f0_clicked)
    f1 = QPushButton(d)
    f1.setText("itian_food!")
    f1.move(75, 50)
    QObject.connect(f1, SIGNAL("clicked()"), f1_clicked)
    f2 = QPushButton(d)
    f2.setText("north_indian_food!")
    f2.move(75, 80)
    QObject.connect(f2, SIGNAL("clicked()"), f2_clicked)
    f3 = QPushButton(d)
    f3.setText("south_indian_food!")
    f3.move(75, 110)
    QObject.connect(f3, SIGNAL("clicked()"), f3_clicked)
    d.exec_()

def b1_clicked():
   print "Your Choice is Cold Drink! Please make an order!"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/cold drink/pepsi.jpg"))
   l1.show()
   d.exec_()


def b2_clicked():
   print "Your Choice is Snacks! Please make an order!"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/Scanks/Scanks3.jpg"))
   l1.show()
   d.exec_()


def b3_clicked():
   print "Your Choice is Fast Food! Please make an order!"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/fast food/pasta.jpg"))
   l1.show()
   d.exec_()


def b4_clicked():
   print "Your Choice is Tea / Coffee! Please make an order!"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/Tea & Coffee /Coffee.jpg"))
   l1.show()
   d.exec_()



def b5_clicked():
   print "Your Choice is Salad! Please make an order!!"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/salad/fruit_salad.jpg"))
   l1.show()
   d.exec_()

def f0_clicked():
   print "Order Chenise Food! please wait few minute !"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/food/chenise_food/chiwmen.jpg"))
   l1.show()
   d.exec_()


def f1_clicked():
   print "Order Itlian Food! please wait few minute !"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/food/itian_food/soup.jpg"))
   l1.show()
   d.exec_()


def f2_clicked():
   print "Order North Food! please wait few minute !"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/food/noth_indian_food/punjabi_tali.jpg"))
   l1.show()
   d.exec_()


def f3_clicked():
   print "Order Sourth Food! please wait few minute !"
   d = QDialog()
   l1 = QLabel(d)
   l1.setPixmap(QPixmap("/home/kush/Downloads/Images/food/south_indian_food/sabhar_bada.jpeg"))
   l1.show()
   d.exec_()


def home():
    t = QMainWindow()
    ui = Ui_HomePage()
    ui.setupUi(t)
    t.show()
    sys.exit(t.exec_())


def close():
    choice = QMessageBox.question(f, 'Extract!', 'Are you sure want to exit Restaurant menu?',
                                  QMessageBox.Yes | QMessageBox.No)
    if choice == QMessageBox.Yes:
        print("Exit Now!")
        sys.exit()
    else:
        pass


def back():
    choice = QMessageBox.question(f, 'Extract!', 'This is first Window of Restaurant menu?',
                                  QMessageBox.Yes | QMessageBox.No)
    if choice == QMessageBox.Yes:
        print("Back is not possible! You'll Exit now")
        sys.exit()
    else:
        pass

if __name__ == '__main__':
    app = QApplication(sys.argv)
    f = QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(f)
    f.show()
    d = QDialog(f)
    ui0 = Ui_Dialog()
    ui0.setupUi(d)
    d.show()
    QObject.connect(ui.home_btn, SIGNAL("clicked()"), home)
    QObject.connect(ui.next_btn, SIGNAL("clicked()"), window)
    QObject.connect(ui.cancel_btn, SIGNAL("clicked()"), close)
    QObject.connect(ui.back_btn, SIGNAL("clicked()"), back)
    sys.exit(app.exec_())


